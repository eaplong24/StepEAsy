import React, { useState, useContext } from 'react';
import { CartContext } from './components/CartContext';
import useShoeData from './components/useShoeData';
import { Link } from 'react-router-dom';

const Unisex = () => {
  const shoesData = useShoeData();
  const { addToCart, cartItems } = useContext(CartContext);
  const [showModal, setShowModal] = useState(false);
  const [selectedShoe, setSelectedShoe] = useState(null);

  // Filter the shoesData array to include only shoes with specific IDs
  const unisexShoes = shoesData.filter((shoe) =>
    [1, 2, 4, 5, 6, 9, 10, 13, 18, 19].includes(shoe.id)
  );

  const handleAddToCart = (shoe) => {
    const alreadyInCart = cartItems.some((item) => item.id === shoe.id);

    if (alreadyInCart) {
      setSelectedShoe(shoe);
      setShowModal(true);
    } else {
      addToCart(shoe);
      console.log(`Added shoe with ID ${shoe.id} to the cart.`);
    }
  };

  const handleBuyNow = (shoe) => {
    const alreadyInCart = cartItems.some((item) => item.id === shoe.id);

    if (alreadyInCart) {
      setSelectedShoe(shoe);
      setShowModal(true);
    } else {
      addToCart(shoe);
      console.log(`Purchased shoe with ID ${shoe.id}.`);
      // Redirect to the cart page or perform any other action for "Buy Now"
    }
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedShoe(null);
  };

  return (
    <div className="unisex">
      <h1>Unisex Shoes</h1>
      <div className="row d-flex">
        {unisexShoes.map((shoe) => (
          <div className="col-4" key={shoe.id}>
            <img src={shoe.image} alt={shoe.name} />
            <h3>{shoe.name}</h3>
            <p>Price: ${shoe.price}</p>
            <button onClick={() => handleAddToCart(shoe)}>Add to Cart</button>
            <Link to="myCart">
              <button onClick={() => handleBuyNow(shoe)}>Buy Now</button>
            </Link>
          </div>
        ))}
      </div>
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Already in My Cart</h2>
            <p>{selectedShoe.name} is already in your cart.</p>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Unisex;
