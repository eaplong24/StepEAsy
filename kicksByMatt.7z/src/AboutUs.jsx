import React from 'react'

const AboutUs = () => {
  return (
    <div>AboutUs
      asdasdsaf
    </div>
  )
}   

export default AboutUs