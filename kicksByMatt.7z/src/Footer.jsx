import React from 'react'

const Footer = () => {
  return (
  <div className="footer-distributed">
    <div className="row">
      <div className="col-6 col-lg-4">
        <div className="footer-left">
          <h3>KicksBy<span>Matt</span></h3>
          <p className="footer-company-name">Copyright © 2023</p>
        </div>
      </div>
      <div className="col-6 col-lg-4">
        <div className="footer-center">
          <div>
            <i className="fa fa-map-marker"></i>
            <p><span>4632 Building GF</span> Obando, Bulacan</p>
          </div>
          <div>
            <i className="fa fa-phone"></i>
            <p>+639-442-78522</p>
          </div>
          <div>
            <i className="fa fa-envelope"></i>
            <p href="mailto:support@company.com">support@kicksbymatt.com</p>
          </div>
        </div>
      </div>
      <div className="col-12 col-lg-4">
        <div className="footer-right">
          <p className="footer-company-about">
            <span>About the company</span>
            © 2023 KicksByMatt. </p>
            <p className="footer-company-about">Designed by Karl Matthew Marquez.</p>
          
          <div className="footer-icons">
            <a href="#"><i className="fa-brands fa fa-facebook"></i></a>
            <a href="#"><i className="fa-brands fa fa-twitter"></i></a>
            <a href="#"><i className="fa-brands fa fa-linkedin"></i></a>
            <a href="#"><i className="fa-brands fa fa-github"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Footer