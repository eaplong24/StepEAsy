import React from 'react'

const Features = () => {
    return (
        <div>
            <h2 className="headertexts">Features</h2>
            <section className="features-area section_gap">
                <div className="container">
                    <div className="row features-inner">
                        <div className="col-lg-3 col-md-6 col-sm-6">
                            <div className="single-features">
                                <i className="fa-solid fa-truck" style={{color:"#000000"}}></i>
                                <h6>Free Delivery</h6>
                                <p>We have Free Delivery in all parts of Metro Manila</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-6">
                            <div className="single-features">
                                <i className="fa-solid fa-right-left" style={{color:"#000000"}}></i>
                                <h6>Return Policy</h6>
                                <p>7-day guaranteed return policy</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-6">
                            <div className="single-features">
                                <i className="fa-sharp fa-solid fa-headset" style={{color:"#000000"}}></i>
                                <h6>24/7 Support</h6>
                                <p>Live chat and call support</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-sm-6">
                            <div className="single-features">
                                <i className="fa-solid fa-credit-card" style={{color:"#000000"}}></i>
                                <h6>Secure Payment</h6>
                                <p>Apple Pay, Gcash, Bank Transfer, and Cash on Delivery</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}

export default Features