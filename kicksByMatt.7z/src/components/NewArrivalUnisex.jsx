import React, { useState, useContext } from 'react';
import { CartContext } from './CartContext';
import useShoeData from './useShoeData';
import { Link } from 'react-router-dom'

const NewArrivalUnisex = () => {
    const shoesData = useShoeData();
    const [selectedShoe, setSelectedShoe] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const { addToCart, cartItems } = useContext(CartContext);

    // Filter the shoesData array to include only shoes with IDs 1, 2, 4, and 5
    const newArrivalUnisex = shoesData.filter(
        shoe => [1, 2, 4, 5].includes(shoe.id)
    );

    const openModal = (shoe) => {
    setSelectedShoe(shoe);
    setShowModal(false);
    };

    const closeModal = () => {
        setSelectedShoe(null);
        setShowModal(false);
    };

    const handleAddToCart = () => {
        const alreadyInCart = cartItems.some(item => item.id === selectedShoe.id);

        if (alreadyInCart) {
        setShowModal(true);
        } else {
        addToCart(selectedShoe);
        console.log('Added to Cart:', selectedShoe);
        }
    };

    const buyNow = () => {
        const alreadyInCart = cartItems.some(item => item.id === selectedShoe.id);

        if (alreadyInCart) {
        setShowModal(true);
        } else {
        addToCart(selectedShoe);
        console.log('Added to Cart:', selectedShoe);
        // Redirect to the cart page or perform any other action for "Buy Now"
        }
    };

    return (
        <div className='newArrivalUnisex'>
        <h1>New Arrivals - Unisex</h1>
        <div className='row d-flex'>
            {newArrivalUnisex.map((shoe, index) => (
            <div className='col-4' key={index}>
                <img src={shoe.image} alt={shoe.name} onClick={() => openModal(shoe)}/>
                <span>{shoe.name}</span>
            </div>
            ))}
        </div>
        {selectedShoe && (
            <div className='modal'>
                <div className='modal-content'>
                    <img src={selectedShoe.image} alt={selectedShoe.name} />
                    <h2>{selectedShoe.name}</h2>
                    <p>Price: {selectedShoe.price}</p>
                    <p>Rate: {selectedShoe.rate}</p>
                    <p>Description: {selectedShoe.description}</p>
                    {!showModal && (
                        <>
                            <button onClick={handleAddToCart}>Add to Cart</button>
                            <button onClick={buyNow}><Link to='myCart'>Buy Now</Link></button>
                        </>
                        )}
                        {showModal && (
                        <div className='modal'>
                            <div className='modal-content'>
                            <p>Already in My Cart</p>
                            <button onClick={closeModal}>Close</button>
                            </div>
                        </div>
                        )}
                    <button onClick={closeModal}>Close</button>
                </div>
            </div>
        )}
        </div>
    );
};

export default NewArrivalUnisex;
