import React, { useEffect } from 'react'

const Carousel = () => {
  // useEffect(() => {
  //   var main = new Splide('#main-slider', {
  //     type: 'fade',
  //     heightRatio: 0.5,
  //     pagination: false,
  //     arrows: false,
  //     cover: true,
  //   });
  
  //   var thumbnails = new Splide('#thumbnail-slider', {
  //     rewind: true,
  //     fixedWidth: 104,
  //     fixedHeight: 58,
  //     isNavigation: true,
  //     gap: 10,
  //     focus: 'center',
  //     pagination: false,
  //     cover: true,
  //     dragMinThreshold: {
  //       mouse: 4,
  //       touch: 10,
  //     },
  //     breakpoints: {
  //       640: {
  //         fixedWidth: 66,
  //         fixedHeight: 38,
  //       },
  //     },
  //   });
  
  //   main.sync(thumbnails);
  //   main.mount();
  //   thumbnails.mount();
  // }, []);

  return (
    <div className="container">
          <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-indicators">
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div className="carousel-inner col-sm-12 col-md-6 col-lg-3">
              <div className="carousel-item active">
                <img src='./src/assets/img/yellow.jpg' className="d-block w-100" alt="..."/>
                <div className="carousel-caption d-none d-md-block">
                  <h5>Get the best deals now!</h5>
                  <p>Sign up now to get our free shipping voucher on your first order</p>
                  {/* <div className="slider-btn">
                    <button className="btn btn-1">Shop now</button>
                    <button className="btn btn-2">Sign up</button>
                  </div> */}
                </div>
              </div>
              <div className="carousel-item">
                <img src='./src/assets/img/donald-martinez-Jfghc6MGpt0-unsplash.jpg' className="d-block w-100" alt="..."/>
                <div className="carousel-caption d-none d-md-block">
                  <h5>Get the best deals now!</h5>
                  <p>Sign up now to get our free shipping voucher on your first order</p>
                  {/* <div className="slider-btn">
                    <button className="btn btn-1">Shop now</button>
                    <button className="btn btn-2">Sign up</button>
                  </div> */}
                </div>
              </div>
              <div className="carousel-item">
                <img src='./src/assets/img/panda.jpg' className="d-block w-100" alt="..."/>
                <div className="carousel-caption d-none d-md-block">
                  <h5>Get the best deals now!</h5>
                  <p>Sign up now to get our free shipping voucher on your first order</p>
                  {/* <div className="slider-btn">
                    <button className="btn btn-1">Shop now</button>
                    <button className="btn btn-2">Sign up</button>
                  </div> */}
                </div>
              </div>
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
              <span className="carousel-control-prev-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
              <span className="carousel-control-next-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>


    // {/* // <div>
    // //   <div className='sectionTitle'>
    // //     <h1>KicksByMatt</h1>
    // //   </div>

    // //   <div className='carousel mx-auto' style={{width: "60%", height: "50%"}}>
    // //     <div className="splide my-5" id="main-slider">
    // //       <div className="splide__track">
    // //         <ul className="splide__list">
    // //           <li className="splide__slide">
    // //             <img src="https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/380697/02/sv01/fnd/IND/fmt/png/,Wild-Rider-Layers-Unisex-Sneakers" className="img-fluid"/>
    // //             <div className="carousel-caption d-none d-md-block">
    // //               <h5>Second slide label</h5>
    // //               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    // //           </div>	
    // //           </li>
    // //           <li className="splide__slide">
    // //             <img src="https://assets.adidas.com/images/w_600,f_auto,q_auto/ad53e2abade1464bb0dcad0c00aaafec_9366/SL20.2_Shoes_Orange_Q46187_01_standard.jpg" className="img-fluid"/>
    // //             <div className="carousel-caption d-none d-md-block">
    // //               <h5>Second slide label</h5>
    // //               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    // //             </div>
    // //           </li>
    // //           <li className="splide__slide">
    // //             <img src="https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/72d2a488-a065-47a1-bf66-e8adfe0ba1f7/air-jordan-xxxvi-low-mens-basketball-shoes-LgcvQl.png" className="img-fluid"/>
    // //             <div className="carousel-caption d-none d-md-block">
    // //               <h5>Second slide label</h5>
    // //               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    // //             </div>
    // //           </li>
    // //         </ul>
    // //       </div>
    // //     </div>

    // //     <div className="splide my-5 mx-auto" style={{width:"60%"}} id="thumbnail-slider">
    // //       <div className="splide__track">
    // //         <ul className="splide__list">
    // //           <li className="splide__slide hvr-grow-shadow">
    // //             <img src="https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/380697/02/sv01/fnd/IND/fmt/png/,Wild-Rider-Layers-Unisex-Sneakers" className="img-fluid"/>
    // //           </li>
    // //           <li className="splide__slide hvr-grow-shadow">
    // //             <img src="https://assets.adidas.com/images/w_600,f_auto,q_auto/ad53e2abade1464bb0dcad0c00aaafec_9366/SL20.2_Shoes_Orange_Q46187_01_standard.jpg" className="img-fluid"/>
    // //           </li>
    // //           <li className="splide__slide hvr-grow-shadow">
    // //             <img src="https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/72d2a488-a065-47a1-bf66-e8adfe0ba1f7/air-jordan-xxxvi-low-mens-basketball-shoes-LgcvQl.png" className="img-fluid"/>
    // //           </li>
    // //         </ul>
    // //       </div>
    // //     </div>
    // //   </div>
    // // </div> */}
      
  )
}
export default Carousel;

  
