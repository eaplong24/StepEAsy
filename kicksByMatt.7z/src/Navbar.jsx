import React, { useContext } from 'react';
import { Link } from "react-router-dom"
import { CartContext } from './components/CartContext';

const Navbar = () => {
    const { cartItems } = useContext(CartContext);
    const cartItemCount = cartItems.length;
    return (
        <div>
            <nav className="navbar navbar-expand-lg fixed-top navbarcolor justify-content-center">
                <div className="container-fluid">
                    <Link to="/" className="navbar-brand d-flex w-50 me-auto">KicksByMatt</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="navbar-collapse collapse w-100" id="navbarNav">
                        <ul className="navbar-nav w-100 justify-content-center">
                            <li className="nav-item">
                                <Link className="nav-link active hover-underline-animation" aria-current="page" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link hover-underline-animation" to="/men" role="button"  aria-expanded="false">
                                    Men
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link hover-underline-animation" to="/unisex" role="button"  aria-expanded="false">
                                    Unisex
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link hover-underline-animation" to="/aboutUs" aria-expanded="false">
                                    About Us
                                </Link>
                            </li>
                        </ul>
                        <ul className="nav navbar-nav ms-auto w-100 justify-content-end">
                            <li className="nav-item">
                                <a className="nav-link hover-underline-animation" to="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="fa-solid fa-magnifying-glass" style={{color:"#ffffff"}}></i>
                                </a>
                                <ul className="dropdown-menu">
                                    <input type="text" name="Searchbar" id="searchbar" placeholder='Search by Brandname'/>
                                    <Link to='/search'><button type="submit"><i className="fa fa-search"></i></button></Link>
                                </ul>   
                            </li>
                            <li className="nav-item">
                                <a className="nav-link hover-underline-animation" href="#" aria-expanded="false" data-bs-toggle="modal" data-bs-target="#LoginModal">
                                <i className="fa-sharp fa-regular fa-user" style={{color:"#ffffff"}}></i>
                                </a>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link hover-underline-animation" to="/mycart" role="button" aria-expanded="false">
                                <i className="fa fa-cart-shopping" style={{color:"#ffffff"}}>({cartItemCount})</i>
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            {/* <nav className="navbar navbar-expand-lg">
                <div className="container-fluid px-5">
                    <a className="navbar-brand w-50 me-auto" href="#">
                        KicksByMatt
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse w-100" id="navbarSupportedContent">
                        <ul className="navbar-nav w-100 justify-content-center align-items-center">
                            <li className="nav-item">
                                <Link className="nav-link hvr-underline-from-left" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link hvr-underline-from-left" to="/men">Men</Link>
                            </li>
                            <li className="nav-item ">
                                <Link className="nav-link hvr-underline-from-left" to="/unisex">Unisex</Link>
                            </li>
                            <li className="nav-item">   
                                <Link className="nav-link hvr-underline-from-left" to="/aboutUs">About Us</Link>
                            </li>
                        </ul>
                        <ul className='navbar-nav ms-auto w-100 justify-content-end'>
                            <li className="nav-item">
                                <a className="fa-solid fa-magnifying-glass" href="#"></a>
                            </li>
                            <li className="nav-item">
                                <a className="fa-sharp fa-regular fa-user" href="#"></a>
                            </li>
                            <li className="nav-item">
                                <a className="fa fa-cart-shopping" href="#"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav> */}
        </div>
    )
}

export default Navbar