import React, { useState, useContext } from 'react';
import { CartContext } from './components/CartContext';
import useShoeData from './components/useShoeData';
import { Link } from 'react-router-dom';

const Men = () => {
  const shoesData = useShoeData();
  const { addToCart, cartItems } = useContext(CartContext);
  const [showModal, setShowModal] = useState(false);

  // Filter the shoesData array to include only shoes with specific IDs
  const menShoes = shoesData.filter((shoe) =>
    [3, 14, 17, 26, 27, 28, 29, 30].includes(shoe.id)
  );

  const handleAddToCart = (shoe) => {
    const alreadyInCart = cartItems.some(item => item.id === shoe.id);

    if (alreadyInCart) {
      setShowModal(true);
    } else {
      addToCart(shoe);
      console.log(`Added shoe with ID ${shoe.id} to the cart.`);
    }
  };

  const handleBuyNow = (shoe) => {
    const alreadyInCart = cartItems.some(item => item.id === shoe.id);

    if (alreadyInCart) {
      setShowModal(true);
    } else {
      addToCart(shoe);
      console.log(`Purchased shoe with ID ${shoe.id}.`);
      // Redirect to the cart page or perform any other action for "Buy Now"
    }
  };

  const closeModal = () => {
    setShowModal(false);
  };

  return (
    <div className="men">
      <h1>Men's Shoes</h1>
      <div className="row d-flex">
        {menShoes.map((shoe) => (
          <div className="col-4" key={shoe.id}>
            <img src={shoe.image} alt={shoe.name} />
            <h3>{shoe.name}</h3>
            <p>Price: ${shoe.price}</p>
            <button onClick={() => handleAddToCart(shoe)}>
              Add to Cart
            </button>
            <Link to='myCart'>
              <button onClick={() => handleBuyNow(shoe)}>Buy Now</button>
            </Link>
          </div>
        ))}
      </div>
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Already in My Cart</h2>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Men;
