import React, { useContext, useState } from 'react';
import { CartContext } from './components/CartContext';

const MyCart = () => {
  const { cartItems, removeFromCart } = useContext(CartContext);
  const [selectedItems, setSelectedItems] = useState([]);
  const [quantities, setQuantities] = useState({});

  const handleCheckboxChange = (event, itemId) => {
    if (event.target.checked) {
      setSelectedItems([...selectedItems, itemId]);
    } else {
      setSelectedItems(selectedItems.filter((id) => id !== itemId));
    }
  };

  const handleDeleteItem = (itemId) => {
    removeFromCart(itemId);
    setSelectedItems(selectedItems.filter((id) => id !== itemId));
    setQuantities((prevQuantities) => {
      const updatedQuantities = { ...prevQuantities };
      delete updatedQuantities[itemId];
      return updatedQuantities;
    });
  };

  const handleQuantityChange = (itemId, quantity) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [itemId]: quantity,
    }));
  };

  const calculateItemTotal = (item) => {
    const quantity = quantities[item.id] || 1;
    return item.price * quantity;
  };

  const calculateCartTotal = () => {
    let total = 0;
    for (const item of cartItems) {
      if (selectedItems.includes(item.id)) {
        total += calculateItemTotal(item);
      }
    }
    return total;
  };

  return (
    <div className="myCart">
      <h1>My Cart</h1>
      {cartItems.length === 0 ? (
        <p>No items in the cart</p>
      ) : (
        <div className="row d-flex">
          <ul className='col-9'>
            {cartItems.map((item, index) => (
              <li key={index}>
                <label>
                  <input
                    type="checkbox"
                    value={item.id}
                    checked={selectedItems.includes(item.id)}
                    onChange={(e) => handleCheckboxChange(e, item.id)}
                  />
                  <img src={item.image} alt={item.name} />
                  <p>{item.name}</p>
                  <p>Price: {item.price}</p>
                  <p>
                    Qty:
                    <input
                      type="number"
                      id={`quantity-${item.id}`}
                      name={`quantity-${item.id}`}
                      min="1"
                      max="10"
                      value={quantities[item.id] || 1}
                      onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                    />
                  </p>
                  <p>Total: {calculateItemTotal(item)}</p>
                  <button onClick={() => handleDeleteItem(item.id)}>
                    Delete
                  </button>
                </label>
              </li>
            ))}
          </ul>
          <p className='col-3'>Cart Total: {calculateCartTotal()}</p>
        </div>
      )}
    </div>
  );
};

export default MyCart;
    